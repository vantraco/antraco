# Preditores H_formula, C_formula, R_formula
